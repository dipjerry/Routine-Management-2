<script src="../assets/vendor/jquery/jquery.min.js"></script>
<!-- <script src="../assets/js/jQuery_v3_2_0.min.js"></script> -->
<script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="../assets/js/jquery-ui.min.js"></script>

<script type="text/javascript" src="../assets/vendor/parsley/dist/parsley.min.js"></script>


<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/plugins/owl.carousel.min.js"></script>
<!-- <script src="../assets/plugins/jquery.dataTables.min.js"></script> -->
<!-- <script src="../assets/plugins/dataTables.responsive.min.js"></script> -->
<script src="../assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="../assets/js/js.js"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

</body>

</html>