<?php

//user_action.php

include('../routine.php');

$object = new routine();

if (isset($_POST["action"])) {
    if ($_POST["action"] == 'fetch') {
        $order_column = array('teacher_code', 'name',  'gender', 'phone', 'email', 'display_image');

        $output = array();

        $main_query = "
		SELECT * FROM teacher_list 
		WHERE ' 
		
		";

        $search_query = '';

        if (isset($_POST["search"]["value"])) {
            $search_query .= 'AND (name LIKE "%' . $_POST["search"]["value"] . '%" ';
            $search_query .= 'OR alias LIKE "%' . $_POST["search"]["value"] . '%" ';
        }

        if (isset($_POST["order"])) {
            $order_query = 'ORDER BY ' . $order_column[$_POST['order']['0']['column']] . ' ' . $_POST['order']['0']['dir'] . ' ';
        } else {
            $order_query = 'ORDER BY id DESC ';
        }

        $limit_query = '';

        if ($_POST["length"] != -1) {
            $limit_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
        }

        $object->query = $main_query . $search_query . $order_query;

        $object->execute();

        $filtered_rows = $object->row_count();

        $object->query .= $limit_query;

        $result = $object->get_result();

        $object->query = $main_query;

        $object->execute();

        $total_rows = $object->row_count();

        $data = array();

        foreach ($result as $row) {
            $sub_array = array();
            $sub_array[] = '<img src="' . $row["user_profile"] . '" class="img-fluid img-thumbnail" width="75" height="75" />';
            $sub_array[] = html_entity_decode($row["user_name"]);
            $sub_array[] = $row["user_contact_no"];
            $sub_array[] = $row["user_email"];
            $sub_array[] = $row["user_password"];
            $sub_array[] = $row["user_type"];
            $sub_array[] = $row["user_created_on"];
            $status = '';
            $delete_button = '';
            $delete_button = '<button type="button" name="delete_button" class="btn btn-danger btn-circle btn-sm delete_button" data-id="' . $row["user_id"] . '" data-status="' . $row["user_status"] . '"><i class="fas fa-times"></i></button>';
            $sub_array[] = '
			<div align="center">
			<button type="button" name="edit_button" class="btn btn-warning btn-circle btn-sm edit_button" data-id="' . $row["user_id"] . '"><i class="fas fa-edit"></i></button>
			&nbsp;
			' . $delete_button . '
			</div>';
            $data[] = $sub_array;
        }

        $output = array(
            "draw"                =>     intval($_POST["draw"]),
            "recordsTotal"      =>  $total_rows,
            "recordsFiltered"     =>     $filtered_rows,
            "data"                =>     $data
        );

        echo json_encode($output);
    }

    if ($_POST["action"] == 'Add') {
        var_dump($_POST["account_username"][0]);
        $error = '';

        $success = '';

        $data = array(
            ':account_email'    =>    $_POST["account_email"],
            ':account_username'    =>    $_POST["account_username"]
        );

        $object->query = "
		SELECT * FROM useraccounts 
		WHERE account_email = :account_email or account_username = :account_username
		";

        $object->execute($data);

        if ($object->row_count() > 0) {
            $error = '<div class="alert alert-danger">User Email Already Exists</div>';
        } else {
            $user_image = '';
            if ($_FILES["profile_image"]["name"] != '') {
                $user_image = upload_image();
            } else {
                $user_image = make_avatar(strtoupper($_POST["account_username"][2]));
            }
            $data = array(
                ':account_name'        =>    $_POST["account_name"],
                ':account_username'        =>    $_POST["account_username"],
                ':account_email'        =>    $_POST["account_email"],
                ':account_password'    =>    MD5($_POST["account_password"]),
                ':user_profile'        =>    $user_image,
            );

            $object->query = "
			INSERT INTO useraccounts 
			(account_name, account_username, account_email, account_password, userimage) 
			VALUES (:account_name, :account_username, :account_email, :account_password, :user_profile)
			";

            $object->execute($data);

            $success = '<div class="alert alert-success">User Added</div>';
        }

        $output = array(
            'error'        =>    $error,
            'success'    =>    $success
        );

        echo json_encode($output);
    }
}

function upload_image()
{
    if (isset($_FILES["profile_image"])) {
        $extension = explode('.', $_FILES['profile_image']['name']);
        $new_name = rand() . '.' . $extension[1];
        $destination = '../uploads/images/admin/' . $new_name;
        move_uploaded_file($_FILES['profile_image']['tmp_name'], $destination);
        return $new_name;
    }
}

function make_avatar($character)
{
    $img_name = time() . ".png";
    $path = "../uploads/images/" . $img_name;
    $image = imagecreate(200, 200);
    $red = rand(0, 255);
    $green = rand(0, 255);
    $blue = rand(0, 255);
    imagecolorallocate($image, 230, 230, 230);
    $textcolor = imagecolorallocate($image, $red, $green, $blue);
    imagettftext($image, 100, 0, 55, 150, $textcolor, 'font/arial.ttf', $character);
    imagepng($image, $path);
    imagedestroy($image);
    return $img_name;
}
